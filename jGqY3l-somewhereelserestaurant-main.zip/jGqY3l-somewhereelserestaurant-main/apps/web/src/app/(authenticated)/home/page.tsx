'use client'

import { useEffect, useState } from 'react'
import { Input, List, Typography, Rate, Row, Col, Card, Space } from 'antd'
import { SearchOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Search } = Input
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [restaurants, setRestaurants] = useState<Model.Restaurant[]>([])
  const [searchTerm, setSearchTerm] = useState<string>('')

  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const restaurantsFound = await Api.Restaurant.findMany({
          includes: ['reviews'],
          filters: {
            name: { ilike: `%${searchTerm}%` },
            location: { ilike: `%${searchTerm}%` },
          },
        })
        setRestaurants(restaurantsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch restaurants', { variant: 'error' })
      }
    }
    fetchRestaurants()
  }, [searchTerm])

  const handleSearch = (value: string) => {
    setSearchTerm(value)
  }

  const renderRestaurantCard = (restaurant: Model.Restaurant) => {
    const averageRating =
      restaurant.reviews?.reduce((acc, review) => acc + review.rating, 0) /
        restaurant.reviews?.length || 0

    return (
      <Card
        key={restaurant.id}
        hoverable
        onClick={() => router.push(`/restaurants/${restaurant.id}`)}
        style={{ marginBottom: 20 }}
      >
        <Title level={4}>{restaurant.name}</Title>
        <Text>{restaurant.location}</Text>
        <div>
          <Rate disabled value={averageRating} />
          <Text> ({restaurant.reviews?.length || 0} reviews)</Text>
        </div>
      </Card>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center">
        <Col span={24} style={{ textAlign: 'center', marginBottom: 20 }}>
          <Title>Restaurants</Title>
          <Text>Find and review restaurants to make a reservation</Text>
        </Col>
        <Col span={24} style={{ textAlign: 'center', marginBottom: 20 }}>
          <Search
            placeholder="Search by name or location"
            enterButton={<SearchOutlined />}
            size="large"
            onSearch={handleSearch}
          />
        </Col>
        <Col span={24}>
          <List
            grid={{ gutter: 16, column: 1 }}
            dataSource={restaurants}
            renderItem={restaurant => (
              <List.Item>{renderRestaurantCard(restaurant)}</List.Item>
            )}
          />
        </Col>
      </Row>
    </PageLayout>
  )
}
