import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { FavoriteDomainFacade } from '@server/modules/favorite/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { FavoriteApplicationEvent } from './favorite.application.event'
import { FavoriteCreateDto } from './favorite.dto'

import { MenuItemDomainFacade } from '../../menuItem/domain'

@Controller('/v1/menuItems')
export class FavoriteByMenuItemController {
  constructor(
    private menuItemDomainFacade: MenuItemDomainFacade,

    private favoriteDomainFacade: FavoriteDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/menuItem/:menuItemId/favorites')
  async findManyMenuItemId(
    @Param('menuItemId') menuItemId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.menuItemDomainFacade.findOneByIdOrFail(menuItemId)

    const items = await this.favoriteDomainFacade.findManyByMenuItem(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/menuItem/:menuItemId/favorites')
  async createByMenuItemId(
    @Param('menuItemId') menuItemId: string,
    @Body() body: FavoriteCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, menuItemId }

    const item = await this.favoriteDomainFacade.create(valuesUpdated)

    await this.eventService.emit<FavoriteApplicationEvent.FavoriteCreated.Payload>(
      FavoriteApplicationEvent.FavoriteCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
