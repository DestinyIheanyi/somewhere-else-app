import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { MenuItemDomainFacade } from '@server/modules/menuItem/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { MenuItemApplicationEvent } from './menuItem.application.event'
import { MenuItemCreateDto } from './menuItem.dto'

import { RestaurantDomainFacade } from '../../restaurant/domain'

@Controller('/v1/restaurants')
export class MenuItemByRestaurantController {
  constructor(
    private restaurantDomainFacade: RestaurantDomainFacade,

    private menuItemDomainFacade: MenuItemDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/restaurant/:restaurantId/menuItems')
  async findManyRestaurantId(
    @Param('restaurantId') restaurantId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.restaurantDomainFacade.findOneByIdOrFail(restaurantId)

    const items = await this.menuItemDomainFacade.findManyByRestaurant(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/restaurant/:restaurantId/menuItems')
  async createByRestaurantId(
    @Param('restaurantId') restaurantId: string,
    @Body() body: MenuItemCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, restaurantId }

    const item = await this.menuItemDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MenuItemApplicationEvent.MenuItemCreated.Payload>(
      MenuItemApplicationEvent.MenuItemCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
