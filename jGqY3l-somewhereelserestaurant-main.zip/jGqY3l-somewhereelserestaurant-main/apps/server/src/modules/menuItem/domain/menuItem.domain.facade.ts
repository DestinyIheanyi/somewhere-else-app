import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { MenuItem } from './menuItem.model'

import { Restaurant } from '../../restaurant/domain'

@Injectable()
export class MenuItemDomainFacade {
  constructor(
    @InjectRepository(MenuItem)
    private repository: Repository<MenuItem>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<MenuItem>): Promise<MenuItem> {
    return this.repository.save(values)
  }

  async update(item: MenuItem, values: Partial<MenuItem>): Promise<MenuItem> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: MenuItem): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<MenuItem> = {},
  ): Promise<MenuItem[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<MenuItem> = {},
  ): Promise<MenuItem> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByRestaurant(
    item: Restaurant,
    queryOptions: RequestHelper.QueryOptions<MenuItem> = {},
  ): Promise<MenuItem[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('restaurant')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        restaurantId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
