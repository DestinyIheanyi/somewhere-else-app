import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { RestaurantDomainModule } from '../domain'
import { RestaurantController } from './restaurant.controller'

@Module({
  imports: [AuthenticationDomainModule, RestaurantDomainModule],
  controllers: [RestaurantController],
  providers: [],
})
export class RestaurantApplicationModule {}
