import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { RestaurantDomainModule } from './restaurant/domain'

import { MenuItemDomainModule } from './menuItem/domain'

import { ReviewDomainModule } from './review/domain'

import { FavoriteDomainModule } from './favorite/domain'

import { ReservationDomainModule } from './reservation/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    RestaurantDomainModule,

    MenuItemDomainModule,

    ReviewDomainModule,

    FavoriteDomainModule,

    ReservationDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
