import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ReviewDomainModule } from '../domain'
import { ReviewController } from './review.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ReviewByUserController } from './reviewByUser.controller'

import { RestaurantDomainModule } from '../../../modules/restaurant/domain'

import { ReviewByRestaurantController } from './reviewByRestaurant.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ReviewDomainModule,

    UserDomainModule,

    RestaurantDomainModule,
  ],
  controllers: [
    ReviewController,

    ReviewByUserController,

    ReviewByRestaurantController,
  ],
  providers: [],
})
export class ReviewApplicationModule {}
