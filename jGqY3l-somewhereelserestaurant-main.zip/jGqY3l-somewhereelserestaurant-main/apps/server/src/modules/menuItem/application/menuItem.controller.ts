import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { MenuItem, MenuItemDomainFacade } from '@server/modules/menuItem/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { MenuItemApplicationEvent } from './menuItem.application.event'
import { MenuItemCreateDto, MenuItemUpdateDto } from './menuItem.dto'

@Controller('/v1/menuItems')
export class MenuItemController {
  constructor(
    private eventService: EventService,
    private menuItemDomainFacade: MenuItemDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.menuItemDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: MenuItemCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.menuItemDomainFacade.create(body)

    await this.eventService.emit<MenuItemApplicationEvent.MenuItemCreated.Payload>(
      MenuItemApplicationEvent.MenuItemCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:menuItemId')
  async findOne(
    @Param('menuItemId') menuItemId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.menuItemDomainFacade.findOneByIdOrFail(
      menuItemId,
      queryOptions,
    )

    return item
  }

  @Patch('/:menuItemId')
  async update(
    @Param('menuItemId') menuItemId: string,
    @Body() body: MenuItemUpdateDto,
  ) {
    const item = await this.menuItemDomainFacade.findOneByIdOrFail(menuItemId)

    const itemUpdated = await this.menuItemDomainFacade.update(
      item,
      body as Partial<MenuItem>,
    )
    return itemUpdated
  }

  @Delete('/:menuItemId')
  async delete(@Param('menuItemId') menuItemId: string) {
    const item = await this.menuItemDomainFacade.findOneByIdOrFail(menuItemId)

    await this.menuItemDomainFacade.delete(item)

    return item
  }
}
