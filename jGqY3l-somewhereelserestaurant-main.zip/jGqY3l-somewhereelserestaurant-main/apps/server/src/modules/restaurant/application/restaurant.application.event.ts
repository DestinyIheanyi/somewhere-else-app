export namespace RestaurantApplicationEvent {
  export namespace RestaurantCreated {
    export const key = 'restaurant.application.restaurant.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
