import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ReservationCreateDto {
  @IsNumber()
  @IsNotEmpty()
  numberOfPeople: number

  @IsString()
  @IsNotEmpty()
  date: string

  @IsString()
  @IsNotEmpty()
  time: string

  @IsString()
  @IsNotEmpty()
  confirmationStatus: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  restaurantId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ReservationUpdateDto {
  @IsNumber()
  @IsOptional()
  numberOfPeople?: number

  @IsString()
  @IsOptional()
  date?: string

  @IsString()
  @IsOptional()
  time?: string

  @IsString()
  @IsOptional()
  confirmationStatus?: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  restaurantId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
