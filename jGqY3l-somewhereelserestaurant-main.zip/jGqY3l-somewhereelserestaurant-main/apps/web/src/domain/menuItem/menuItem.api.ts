import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { MenuItem } from './menuItem.model'

export class MenuItemApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<MenuItem>,
  ): Promise<MenuItem[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/menuItems${buildOptions}`)
  }

  static findOne(
    menuItemId: string,
    queryOptions?: ApiHelper.QueryOptions<MenuItem>,
  ): Promise<MenuItem> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/menuItems/${menuItemId}${buildOptions}`)
  }

  static createOne(values: Partial<MenuItem>): Promise<MenuItem> {
    return HttpService.api.post(`/v1/menuItems`, values)
  }

  static updateOne(
    menuItemId: string,
    values: Partial<MenuItem>,
  ): Promise<MenuItem> {
    return HttpService.api.patch(`/v1/menuItems/${menuItemId}`, values)
  }

  static deleteOne(menuItemId: string): Promise<void> {
    return HttpService.api.delete(`/v1/menuItems/${menuItemId}`)
  }

  static findManyByRestaurantId(
    restaurantId: string,
    queryOptions?: ApiHelper.QueryOptions<MenuItem>,
  ): Promise<MenuItem[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/restaurants/restaurant/${restaurantId}/menuItems${buildOptions}`,
    )
  }

  static createOneByRestaurantId(
    restaurantId: string,
    values: Partial<MenuItem>,
  ): Promise<MenuItem> {
    return HttpService.api.post(
      `/v1/restaurants/restaurant/${restaurantId}/menuItems`,
      values,
    )
  }
}
