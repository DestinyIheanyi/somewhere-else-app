import { MenuItem } from '../menuItem'

import { Review } from '../review'

import { Reservation } from '../reservation'

export class Restaurant {
  id: string

  name: string

  location: string

  contactInfo: string

  mapLocation: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  menuItems?: MenuItem[]

  reviews?: Review[]

  reservations?: Reservation[]
}
