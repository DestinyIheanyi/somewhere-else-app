import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { RestaurantDomainFacade } from './restaurant.domain.facade'
import { Restaurant } from './restaurant.model'

@Module({
  imports: [TypeOrmModule.forFeature([Restaurant]), DatabaseHelperModule],
  providers: [RestaurantDomainFacade, RestaurantDomainFacade],
  exports: [RestaurantDomainFacade],
})
export class RestaurantDomainModule {}
