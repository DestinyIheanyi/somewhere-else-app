import { Restaurant } from '../restaurant'

import { Favorite } from '../favorite'

export class MenuItem {
  id: string

  name: string

  description?: string

  price: number

  dishType: string

  restaurantId: string

  restaurant?: Restaurant

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  favorites?: Favorite[]
}
