export interface IEvent {
  key: string
  payload: any
}
