import { User } from '../user'

import { Restaurant } from '../restaurant'

export class Reservation {
  id: string

  numberOfPeople: number

  date: string

  time: string

  confirmationStatus: string

  userId: string

  user?: User

  restaurantId: string

  restaurant?: Restaurant

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
