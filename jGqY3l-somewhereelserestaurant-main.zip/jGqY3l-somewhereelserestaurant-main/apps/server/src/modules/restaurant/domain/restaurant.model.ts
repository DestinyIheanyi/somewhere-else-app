import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { MenuItem } from '../../../modules/menuItem/domain'

import { Review } from '../../../modules/review/domain'

import { Reservation } from '../../../modules/reservation/domain'

@Entity()
export class Restaurant {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  name: string

  @Column({})
  location: string

  @Column({})
  contactInfo: string

  @Column({})
  mapLocation: string

  @OneToMany(() => MenuItem, child => child.restaurant)
  menuItems?: MenuItem[]

  @OneToMany(() => Review, child => child.restaurant)
  reviews?: Review[]

  @OneToMany(() => Reservation, child => child.restaurant)
  reservations?: Reservation[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
