import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Restaurant } from '../../../modules/restaurant/domain'

@Entity()
export class Review {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ColumnNumeric({ type: 'numeric' })
  rating: number

  @Column({ nullable: true })
  comment?: string

  @Column({ nullable: true })
  photoUrl?: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.reviews)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  restaurantId: string

  @ManyToOne(() => Restaurant, parent => parent.reviews)
  @JoinColumn({ name: 'restaurantId' })
  restaurant?: Restaurant

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
