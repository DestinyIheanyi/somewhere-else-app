import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Restaurant } from './restaurant.model'

export class RestaurantApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Restaurant>,
  ): Promise<Restaurant[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/restaurants${buildOptions}`)
  }

  static findOne(
    restaurantId: string,
    queryOptions?: ApiHelper.QueryOptions<Restaurant>,
  ): Promise<Restaurant> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/restaurants/${restaurantId}${buildOptions}`)
  }

  static createOne(values: Partial<Restaurant>): Promise<Restaurant> {
    return HttpService.api.post(`/v1/restaurants`, values)
  }

  static updateOne(
    restaurantId: string,
    values: Partial<Restaurant>,
  ): Promise<Restaurant> {
    return HttpService.api.patch(`/v1/restaurants/${restaurantId}`, values)
  }

  static deleteOne(restaurantId: string): Promise<void> {
    return HttpService.api.delete(`/v1/restaurants/${restaurantId}`)
  }
}
