import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  Restaurant,
  RestaurantDomainFacade,
} from '@server/modules/restaurant/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { RestaurantApplicationEvent } from './restaurant.application.event'
import { RestaurantCreateDto, RestaurantUpdateDto } from './restaurant.dto'

@Controller('/v1/restaurants')
export class RestaurantController {
  constructor(
    private eventService: EventService,
    private restaurantDomainFacade: RestaurantDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.restaurantDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: RestaurantCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.restaurantDomainFacade.create(body)

    await this.eventService.emit<RestaurantApplicationEvent.RestaurantCreated.Payload>(
      RestaurantApplicationEvent.RestaurantCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:restaurantId')
  async findOne(
    @Param('restaurantId') restaurantId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.restaurantDomainFacade.findOneByIdOrFail(
      restaurantId,
      queryOptions,
    )

    return item
  }

  @Patch('/:restaurantId')
  async update(
    @Param('restaurantId') restaurantId: string,
    @Body() body: RestaurantUpdateDto,
  ) {
    const item =
      await this.restaurantDomainFacade.findOneByIdOrFail(restaurantId)

    const itemUpdated = await this.restaurantDomainFacade.update(
      item,
      body as Partial<Restaurant>,
    )
    return itemUpdated
  }

  @Delete('/:restaurantId')
  async delete(@Param('restaurantId') restaurantId: string) {
    const item =
      await this.restaurantDomainFacade.findOneByIdOrFail(restaurantId)

    await this.restaurantDomainFacade.delete(item)

    return item
  }
}
