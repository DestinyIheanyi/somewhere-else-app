import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { MenuItemDomainFacade } from './menuItem.domain.facade'
import { MenuItem } from './menuItem.model'

@Module({
  imports: [TypeOrmModule.forFeature([MenuItem]), DatabaseHelperModule],
  providers: [MenuItemDomainFacade, MenuItemDomainFacade],
  exports: [MenuItemDomainFacade],
})
export class MenuItemDomainModule {}
