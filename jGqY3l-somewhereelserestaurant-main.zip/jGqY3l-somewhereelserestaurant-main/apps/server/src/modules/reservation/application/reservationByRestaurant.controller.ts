import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ReservationDomainFacade } from '@server/modules/reservation/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ReservationApplicationEvent } from './reservation.application.event'
import { ReservationCreateDto } from './reservation.dto'

import { RestaurantDomainFacade } from '../../restaurant/domain'

@Controller('/v1/restaurants')
export class ReservationByRestaurantController {
  constructor(
    private restaurantDomainFacade: RestaurantDomainFacade,

    private reservationDomainFacade: ReservationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/restaurant/:restaurantId/reservations')
  async findManyRestaurantId(
    @Param('restaurantId') restaurantId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.restaurantDomainFacade.findOneByIdOrFail(restaurantId)

    const items = await this.reservationDomainFacade.findManyByRestaurant(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/restaurant/:restaurantId/reservations')
  async createByRestaurantId(
    @Param('restaurantId') restaurantId: string,
    @Body() body: ReservationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, restaurantId }

    const item = await this.reservationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ReservationApplicationEvent.ReservationCreated.Payload>(
      ReservationApplicationEvent.ReservationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
