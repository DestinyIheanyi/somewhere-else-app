import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationRestaurantSubscriber } from './subscribers/notification.restaurant.subscriber'

import { NotificationMenuItemSubscriber } from './subscribers/notification.menuItem.subscriber'

import { NotificationReviewSubscriber } from './subscribers/notification.review.subscriber'

import { NotificationFavoriteSubscriber } from './subscribers/notification.favorite.subscriber'

import { NotificationReservationSubscriber } from './subscribers/notification.reservation.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationRestaurantSubscriber,

    NotificationMenuItemSubscriber,

    NotificationReviewSubscriber,

    NotificationFavoriteSubscriber,

    NotificationReservationSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
