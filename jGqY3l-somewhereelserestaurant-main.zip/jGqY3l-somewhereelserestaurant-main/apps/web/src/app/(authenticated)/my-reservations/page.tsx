'use client'

import { useEffect, useState } from 'react'
import { List, Button, Typography, Row, Col, Card, Space } from 'antd'
import { DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function MyReservationsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [reservations, setReservations] = useState<Model.Reservation[]>([])

  useEffect(() => {
    if (userId) {
      Api.Reservation.findManyByUserId(userId, { includes: ['restaurant'] })
        .then(setReservations)
        .catch(() =>
          enqueueSnackbar('Failed to fetch reservations', { variant: 'error' }),
        )
    }
  }, [userId])

  const handleCancelReservation = async (reservationId: string) => {
    try {
      await Api.Reservation.deleteOne(reservationId)
      setReservations(
        reservations.filter(reservation => reservation.id !== reservationId),
      )
      enqueueSnackbar('Reservation cancelled successfully', {
        variant: 'success',
      })
    } catch {
      enqueueSnackbar('Failed to cancel reservation', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center">
        <Col span={24}>
          <Title level={2}>My Reservations</Title>
          <Text>View and manage your upcoming reservations.</Text>
        </Col>
      </Row>
      <Row justify="center" style={{ marginTop: '20px' }}>
        <Col span={24}>
          <List
            grid={{ gutter: 16, column: 1 }}
            dataSource={reservations}
            renderItem={reservation => (
              <List.Item>
                <Card
                  title={reservation.restaurant?.name}
                  extra={
                    <Button
                      type="primary"
                      danger
                      icon={<DeleteOutlined />}
                      onClick={() => handleCancelReservation(reservation.id)}
                    >
                      Cancel
                    </Button>
                  }
                >
                  <Space direction="vertical">
                    <Text strong>Date: </Text>
                    <Text>
                      {dayjs(reservation.date).format('MMMM D, YYYY')}
                    </Text>
                    <Text strong>Time: </Text>
                    <Text>{reservation.time}</Text>
                    <Text strong>Number of People: </Text>
                    <Text>{reservation.numberOfPeople}</Text>
                  </Space>
                </Card>
              </List.Item>
            )}
          />
        </Col>
      </Row>
    </PageLayout>
  )
}
