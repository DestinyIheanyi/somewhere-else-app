'use client'

import { useEffect, useState } from 'react'
import {
  Typography,
  Row,
  Col,
  Card,
  Button,
  Rate,
  Input,
  Upload,
  message,
  Select,
  Divider,
} from 'antd'
import {
  HeartOutlined,
  HeartFilled,
  StarOutlined,
  UploadOutlined,
  ShareAltOutlined,
  EnvironmentOutlined,
  PhoneOutlined,
} from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
const { TextArea } = Input
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function RestaurantDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [restaurant, setRestaurant] = useState<Model.Restaurant | null>(null)
  const [menuItems, setMenuItems] = useState<Model.MenuItem[]>([])
  const [reviews, setReviews] = useState<Model.Review[]>([])
  const [favorites, setFavorites] = useState<string[]>([])
  const [newReview, setNewReview] = useState({
    rating: 0,
    comment: '',
    photoUrl: '',
  })
  const [fileList, setFileList] = useState<any[]>([])
  const [filter, setFilter] = useState<string | null>(null)

  useEffect(() => {
    const fetchRestaurantDetails = async () => {
      try {
        const restaurantData = await Api.Restaurant.findOne(
          params.restaurantId,
          { includes: ['menuItems', 'reviews', 'reviews.user'] },
        )
        setRestaurant(restaurantData)
        setMenuItems(restaurantData.menuItems || [])
        setReviews(restaurantData.reviews || [])
      } catch (error) {
        enqueueSnackbar('Failed to load restaurant details', {
          variant: 'error',
        })
      }
    }

    fetchRestaurantDetails()
  }, [params.restaurantId])

  const handleFavorite = async (menuItemId: string) => {
    try {
      if (favorites.includes(menuItemId)) {
        await Api.Favorite.deleteOne(favorites.find(fav => fav === menuItemId)!)
        setFavorites(favorites.filter(fav => fav !== menuItemId))
      } else {
        const favorite = await Api.Favorite.createOneByUserId(userId!, {
          menuItemId,
        })
        setFavorites([...favorites, favorite.menuItemId])
      }
    } catch (error) {
      enqueueSnackbar('Failed to update favorites', { variant: 'error' })
    }
  }

  const handleReviewSubmit = async () => {
    try {
      const review = await Api.Review.createOneByUserId(userId!, {
        ...newReview,
        restaurantId: restaurant!.id,
      })
      setReviews([...reviews, review])
      setNewReview({ rating: 0, comment: '', photoUrl: '' })
      setFileList([])
      enqueueSnackbar('Review submitted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to submit review', { variant: 'error' })
    }
  }

  const handleUpload = async (options: any) => {
    const { file } = options
    const url = await Api.Upload.upload(file)
    setFileList([{ url, status: 'done' }])
    setNewReview({ ...newReview, photoUrl: url })
  }

  const filteredMenuItems = filter
    ? menuItems.filter(item => item.dishType === filter)
    : menuItems

  return (
    <PageLayout layout="narrow">
      <Title level={2}>{restaurant?.name}</Title>
      <Paragraph>{restaurant?.location}</Paragraph>
      <Paragraph>
        <PhoneOutlined /> {restaurant?.contactInfo}
      </Paragraph>
      <Paragraph>
        <EnvironmentOutlined />{' '}
        <a
          href={restaurant?.mapLocation}
          target="_blank"
          rel="noopener noreferrer"
        >
          View on Map
        </a>
      </Paragraph>
      <Button icon={<ShareAltOutlined />}>Share</Button>
      <Divider />
      <Title level={3}>Menu</Title>
      <Select
        placeholder="Filter by dish type"
        onChange={value => setFilter(value)}
        allowClear
      >
        <Option value="appetizers">Appetizers</Option>
        <Option value="main courses">Main Courses</Option>
        <Option value="desserts">Desserts</Option>
      </Select>
      <Row gutter={[16, 16]}>
        {filteredMenuItems.map(item => (
          <Col span={8} key={item.id}>
            <Card
              title={item.name}
              extra={
                favorites.includes(item.id) ? (
                  <HeartFilled onClick={() => handleFavorite(item.id)} />
                ) : (
                  <HeartOutlined onClick={() => handleFavorite(item.id)} />
                )
              }
            >
              <Paragraph>{item.description}</Paragraph>
              <Paragraph>{item.price}</Paragraph>
            </Card>
          </Col>
        ))}
      </Row>
      <Divider />
      <Title level={3}>Reviews</Title>
      {reviews.map(review => (
        <Card key={review.id}>
          <Rate disabled value={review.rating} />
          <Paragraph>{review.comment}</Paragraph>
          {review.photoUrl && (
            <img src={review.photoUrl} alt="Review" style={{ width: '100%' }} />
          )}
          <Text>{review.user?.name}</Text>
          <Text>{dayjs(review.dateCreated).format('MMMM D, YYYY')}</Text>
        </Card>
      ))}
      <Divider />
      <Title level={3}>Leave a Review</Title>
      <Rate
        onChange={value => setNewReview({ ...newReview, rating: value })}
        value={newReview.rating}
      />
      <TextArea
        rows={4}
        onChange={e => setNewReview({ ...newReview, comment: e.target.value })}
        value={newReview.comment}
      />
      <Upload fileList={fileList} customRequest={handleUpload} maxCount={1}>
        <Button icon={<UploadOutlined />}>Upload Photo</Button>
      </Upload>
      <Button type="primary" onClick={handleReviewSubmit}>
        Submit Review
      </Button>
    </PageLayout>
  )
}
