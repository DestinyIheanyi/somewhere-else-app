import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { MenuItem } from '../../../modules/menuItem/domain'

@Entity()
export class Favorite {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.favorites)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  menuItemId: string

  @ManyToOne(() => MenuItem, parent => parent.favorites)
  @JoinColumn({ name: 'menuItemId' })
  menuItem?: MenuItem

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
