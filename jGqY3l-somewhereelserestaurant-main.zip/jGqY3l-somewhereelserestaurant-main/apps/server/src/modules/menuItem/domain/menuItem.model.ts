import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Restaurant } from '../../../modules/restaurant/domain'

import { Favorite } from '../../../modules/favorite/domain'

@Entity()
export class MenuItem {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  name: string

  @Column({ nullable: true })
  description?: string

  @ColumnNumeric({ type: 'numeric' })
  price: number

  @Column({})
  dishType: string

  @Column({})
  restaurantId: string

  @ManyToOne(() => Restaurant, parent => parent.menuItems)
  @JoinColumn({ name: 'restaurantId' })
  restaurant?: Restaurant

  @OneToMany(() => Favorite, child => child.menuItem)
  favorites?: Favorite[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
