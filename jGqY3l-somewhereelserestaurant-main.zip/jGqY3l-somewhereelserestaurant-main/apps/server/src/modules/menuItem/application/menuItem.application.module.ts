import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MenuItemDomainModule } from '../domain'
import { MenuItemController } from './menuItem.controller'

import { RestaurantDomainModule } from '../../../modules/restaurant/domain'

import { MenuItemByRestaurantController } from './menuItemByRestaurant.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MenuItemDomainModule,

    RestaurantDomainModule,
  ],
  controllers: [MenuItemController, MenuItemByRestaurantController],
  providers: [],
})
export class MenuItemApplicationModule {}
