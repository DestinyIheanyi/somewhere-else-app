import { User } from '../user'

import { MenuItem } from '../menuItem'

export class Favorite {
  id: string

  userId: string

  user?: User

  menuItemId: string

  menuItem?: MenuItem

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
