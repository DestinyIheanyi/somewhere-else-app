import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { FavoriteDomainModule } from '../domain'
import { FavoriteController } from './favorite.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { FavoriteByUserController } from './favoriteByUser.controller'

import { MenuItemDomainModule } from '../../../modules/menuItem/domain'

import { FavoriteByMenuItemController } from './favoriteByMenuItem.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    FavoriteDomainModule,

    UserDomainModule,

    MenuItemDomainModule,
  ],
  controllers: [
    FavoriteController,

    FavoriteByUserController,

    FavoriteByMenuItemController,
  ],
  providers: [],
})
export class FavoriteApplicationModule {}
