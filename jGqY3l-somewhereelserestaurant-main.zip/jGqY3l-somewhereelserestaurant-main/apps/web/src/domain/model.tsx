import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'
import {
  BillingPayment as BillingPaymentModel,
  BillingProduct as BillingProductModel,
  BillingSubscription as BillingSubscriptionModel,
} from './billing/billing.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Restaurant as RestaurantModel } from './restaurant/restaurant.model'

import { MenuItem as MenuItemModel } from './menuItem/menuItem.model'

import { Review as ReviewModel } from './review/review.model'

import { Favorite as FavoriteModel } from './favorite/favorite.model'

import { Reservation as ReservationModel } from './reservation/reservation.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}
  export class BillingProduct extends BillingProductModel {}
  export class BillingPayment extends BillingPaymentModel {}
  export class BillingSubscription extends BillingSubscriptionModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Restaurant extends RestaurantModel {}

  export class MenuItem extends MenuItemModel {}

  export class Review extends ReviewModel {}

  export class Favorite extends FavoriteModel {}

  export class Reservation extends ReservationModel {}
}
