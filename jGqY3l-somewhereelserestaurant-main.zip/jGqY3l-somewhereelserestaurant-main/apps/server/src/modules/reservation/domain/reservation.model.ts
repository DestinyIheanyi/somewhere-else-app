import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Restaurant } from '../../../modules/restaurant/domain'

@Entity()
export class Reservation {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ColumnNumeric({ type: 'numeric' })
  numberOfPeople: number

  @Column({})
  date: string

  @Column({})
  time: string

  @Column({})
  confirmationStatus: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.reservations)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  restaurantId: string

  @ManyToOne(() => Restaurant, parent => parent.reservations)
  @JoinColumn({ name: 'restaurantId' })
  restaurant?: Restaurant

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
