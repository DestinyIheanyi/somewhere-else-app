'use client'

import { useState } from 'react'
import {
  Form,
  InputNumber,
  DatePicker,
  TimePicker,
  Button,
  Typography,
  Row,
  Col,
  Card,
} from 'antd'
import { CheckCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ReservationPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [loading, setLoading] = useState(false)

  const onFinish = async (values: any) => {
    if (!userId) {
      enqueueSnackbar('You must be logged in to make a reservation', {
        variant: 'error',
      })
      return
    }

    setLoading(true)

    try {
      const reservationValues = {
        numberOfPeople: values.numberOfPeople,
        date: dayjs(values.date).format('YYYY-MM-DD'),
        time: values.time.format('HH:mm'),
        confirmationStatus: 'Pending',
        restaurantId: params.restaurantId,
        userId: userId,
      }

      await Api.Reservation.createOneByUserId(userId, reservationValues)
      enqueueSnackbar('Reservation successfully made!', { variant: 'success' })
      router.push('/my-reservations')
    } catch (error) {
      enqueueSnackbar('Failed to make a reservation', { variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center">
        <Col span={24}>
          <Card>
            <Title level={2}>Make a Reservation</Title>
            <Text>
              Secure your table by making a reservation at our restaurant.
            </Text>
            <Form
              layout="vertical"
              onFinish={onFinish}
              style={{ marginTop: 20 }}
            >
              <Form.Item
                label="Number of People"
                name="numberOfPeople"
                rules={[
                  {
                    required: true,
                    message: 'Please specify the number of people',
                  },
                ]}
              >
                <InputNumber min={1} max={20} style={{ width: '100%' }} />
              </Form.Item>
              <Form.Item
                label="Date"
                name="date"
                rules={[{ required: true, message: 'Please select a date' }]}
              >
                <DatePicker style={{ width: '100%' }} />
              </Form.Item>
              <Form.Item
                label="Time"
                name="time"
                rules={[{ required: true, message: 'Please select a time' }]}
              >
                <TimePicker style={{ width: '100%' }} format="HH:mm" />
              </Form.Item>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  loading={loading}
                  icon={<CheckCircleOutlined />}
                >
                  Confirm Reservation
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
