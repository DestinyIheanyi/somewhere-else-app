import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ReservationDomainModule } from '../domain'
import { ReservationController } from './reservation.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ReservationByUserController } from './reservationByUser.controller'

import { RestaurantDomainModule } from '../../../modules/restaurant/domain'

import { ReservationByRestaurantController } from './reservationByRestaurant.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ReservationDomainModule,

    UserDomainModule,

    RestaurantDomainModule,
  ],
  controllers: [
    ReservationController,

    ReservationByUserController,

    ReservationByRestaurantController,
  ],
  providers: [],
})
export class ReservationApplicationModule {}
