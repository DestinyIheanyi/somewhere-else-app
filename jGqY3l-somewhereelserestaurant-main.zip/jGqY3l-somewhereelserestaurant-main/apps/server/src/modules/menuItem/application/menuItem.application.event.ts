export namespace MenuItemApplicationEvent {
  export namespace MenuItemCreated {
    export const key = 'menuItem.application.menuItem.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
