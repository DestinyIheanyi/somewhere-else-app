import { User } from '../user'

import { Restaurant } from '../restaurant'

export class Review {
  id: string

  rating: number

  comment?: string

  photoUrl?: string

  userId: string

  user?: User

  restaurantId: string

  restaurant?: Restaurant

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
